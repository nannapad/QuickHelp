import "./css/Footer.css";

const Footer = () => {
    return ( 
    <footer className="footer">
        <p>© 2024 Quick-Help. All rights reserved.</p>
        
        <p>Built with ❤️ by the Quick-Help Team.</p>


    </footer>
    );
}
 
export default Footer;